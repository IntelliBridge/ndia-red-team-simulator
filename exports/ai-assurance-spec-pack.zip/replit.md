# AI Assurance

A collaboration-ready starting point for general-purpose AI evaluation research and a proposed non-operational proof of concept.

## Project status and scope

- The user requested a shared project for collaboration; no evaluation application has been implemented.
- Start with `README.md`, `docs/project-brief.md`, `docs/team-backlog.md`, and `CONTRIBUTING.md`.
- The user requested Spec Kit–style spec-driven development. `specs/README.md` indexes feature packages; follow constitution → spec → clarify → plan → tasks → analyze → implement → verify.
- Feature plans and tasks remain drafts until their review gates close. No Spec Kit CLI or slash-command integration is installed.
- The first evaluation domain is undecided. Do not treat earlier recommendations or reference links as approval to build a combined vision/LLM/agent platform.
- Preserve the distinction between observed evidence, interpretations, and candidate recommendations.
- The proposed prototype uses public or synthetic data. Operational military systems, combat targeting, and weapons optimization are outside scope.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `docs/` — shared brief, suggested backlog, and original reference document.
- `specs/` — feature specs, proposed plans, task lists, and shared decision/contract guidance.
- `.specify/` — project-authored constitution and document templates, not a full Spec Kit installation.
- `artifacts/api-server/` — existing Express scaffold.
- `artifacts/mockup-sandbox/` — existing component-preview scaffold, not an implemented evaluation UI.
- `lib/api-spec/openapi.yaml` — existing API contract.

## Architecture decisions

- ART, SHAP, garak, and OpenSandbox are research references, not installed or validated integrations.
- No final model format, runtime, evaluation domain, or external provider has been selected.

## Product

Only the collaboration starter documents exist so far. See the project brief for the proposed workflow and explicit exclusions.

## User preferences

No project-wide preferences have been confirmed.

## Gotchas

- The original document is retained unchanged in `docs/references/original-use-case.docx`; its requested capabilities are not current application features.
- Project collaboration does not require publishing an application.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
