# AI Assurance

A collaborative starting point for general-purpose AI evaluation research, evidence review, and a non-operational proof of concept.

**Current status:** project kickoff and use-case analysis. The repository contains an application scaffold, not a working evaluation platform. No models have been tested, no integrations have been connected, and no collaborators have been invited automatically.

## Start here

- [Feature specifications](specs/README.md) — eight review-ready feature packages, dependencies, and proposed team ownership.
- [Spec-driven workflow](docs/spec-driven-workflow.md) — how the team moves from a specification to an approved plan and tasks.
- [Project brief](docs/project-brief.md) — context, source analysis, proposed scope, and open decisions.
- [Team backlog](docs/team-backlog.md) — entry point to feature-level work and review gates.
- [Contributing guide](CONTRIBUTING.md) — onboarding, collaboration, and review conventions.
- [Original supplied document](docs/references/original-use-case.docx) — retained unchanged as source material.
- [Development guide](replit.md) — existing scaffold and development commands.

The brief distinguishes the user's original requirements from recommendations made during analysis. The first evaluation domain remains an open team decision; vision, language-model, and agent evaluation are not interchangeable. Feature packages follow a Spec Kit–style process; no Spec Kit CLI or command integration is installed.

## Invite your team

Open **Invite** in the project's upper-right header. In the Access panel, enter a teammate's username or email and choose the appropriate access level. Review access before sending the invitation.

You do **not** need to publish an application to collaborate on the project. Project access and application publishing are separate.

Official guidance: [Invite teammates](https://docs.replit.com/build/invite-teammates).

## Working boundaries

Use public or synthetic, non-sensitive data for the proposed prototype. Do not add credentials, private model artifacts, or operational datasets to the repository. Evaluation results are evidence for human review, not certification of safety or operational readiness.