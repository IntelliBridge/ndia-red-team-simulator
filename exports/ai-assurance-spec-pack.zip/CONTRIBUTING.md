# Contributing to AI Assurance

## Onboarding

1. Read the [project brief](docs/project-brief.md), including its open decisions.
2. Review the [feature map](specs/README.md) and agree on ownership before starting.
3. Use the [development guide](replit.md) for the existing scaffold and commands.
4. Agree on the first benign evaluation domain before implementing an evaluation engine.

The current repository is a scaffold with documentation. There is no completed model scanner, evaluation dashboard, report generator, or integrated sandbox to rely on yet.

## Spec-driven development

Follow the [spec-driven workflow](docs/spec-driven-workflow.md). Read the [constitution](.specify/memory/constitution.md), the feature's `spec.md`, `plan.md`, and `tasks.md`, and its relevant shared decisions.

- Specify and clarify behavior before implementing.
- Complete the readiness review before treating a draft plan as approved.
- Reference feature/story/task and requirement IDs in contributions.
- Update the specification first when intended behavior changes.
- Keep task completion tied to genuine implementation and acceptance evidence.
- The existing files are Spec Kit–style documents; they do not install Spec Kit commands.

## Collaborator access

The project owner can select **Invite** in the upper-right header, enter a teammate's username or email in the Access panel, and choose the appropriate access level. Review permissions before inviting.

Publishing is not required for project collaboration. A published app link is not a substitute for project access.

Source: [Replit — Invite teammates](https://docs.replit.com/build/invite-teammates).

## Working together

- Keep changes small and focused on an agreed workstream.
- Coordinate before editing the same files.
- Document product decisions in the brief; do not turn recommendations into approved requirements without agreement.
- Include a short change summary and relevant checks when handing work to a reviewer.
- Update documentation when behavior or scope changes.
- Avoid introducing multiple providers, model formats, or evaluation domains in one change.

## Data and evidence

- Use public or synthetic, non-sensitive data for the proposed prototype.
- Never commit credentials, environment files, private model artifacts, or sensitive datasets.
- Do not run uploaded code or deserialize untrusted model files before the execution approach is reviewed.
- Label demonstration data and hypothetical findings explicitly.
- Do not imply that a visualization establishes root cause or that passing an evaluation establishes complete safety.
- Do not connect operational military systems or build combat-targeting capabilities.

## Verification

Documentation-only changes should be checked for accurate sources, working local links, and a clear distinction between existing and proposed functionality.

For future software contributions, use the applicable commands in [replit.md](replit.md), add focused checks for changed behavior, and record what was actually verified. Never describe an untested integration as working.